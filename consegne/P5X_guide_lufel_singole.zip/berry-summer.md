# Ichigo Shikano·Summer — BERRY·Summer (dati lufel.net)
Fonte: https://lufel.net/en/character/berry-summer/ · letto il 2026-11-14 con il browser integrato (spoiler attivi) · Stato Global: NON RILASCIATA (lufel: "Not Released"; il set Happiness è marcato "#NOT RELEASED IN GLOBAL SERVER#").
Convenzione: nomi di skill, awareness, armi, Persona, set e stat lasciati in inglese come su lufel.net; condizioni ed effetti tradotti in italiano. Valori skill = LV10 / LV10+Minds 5 / LV13 / LV13+Minds 5. Valori armi = refinement R0/R1/R2/R3/R4/R5/R6.

## Scheda
| Campo | Valore |
|---|---|
| Nome | Ichigo Shikano·Summer |
| Codename | BERRY·Summer |
| Persona | Thelxiepeia |
| Rarità / tipo | 5★ · Limited |
| Elemento | Psychokinesis (Psy) |
| Posizione | Medic |
| Ruolo (lufel) | non indicato |
| Tag (lufel) | Healing · Crit Rate |
| Resistenza / Debolezza | Res: Psy · Wk: Curse |

## Character Review (lufel)
- Ichigo Shikano·Summer è una healer e sub-DPS che all'inizio della battaglia fa salire tutti gli alleati sulla [Miracle Ichi-Boat], creando una struttura a vita condivisa.
- Gli HP attuali e massimi di tutti gli alleati vengono messi in comune nella [Miracle Ichi-Boat], i loro HP sono portati a 1 e la barca subisce tutti i danni e le cure ricevuti.
- Con un alleato Psy nel party si usa la Skill 1; con un alleato [Summer] nel party si usa la Skill 2, per ottenere rispettivamente [Illusion Seal]/[Ocean's Seal]. I due Seal hanno lo stesso effetto.
- La Skill 3 fornisce cura AoE e Crit Rate e consuma un Seal per aumentare molto il Crit DMG degli alleati Psy/[Summer]. Designa inoltre il bersaglio principale come [Helmsman].
- Alla fine del turno del [Helmsman] si attiva [Ram: Miracle Ichi-Boat]. Questo attacco aggiuntivo usa gli HP massimi della [Miracle Ichi-Boat] e l'ATK del [Helmsman]; l'attributo del danno segue l'affinità della Persona del [Helmsman] ed è calcolato con Pierce, DMG Bonus, DMG Amp e stat critiche del [Helmsman].
- [Ram: Miracle Ichi-Boat] conta come skill Persona di Ichigo Shikano·Summer, quindi si attivano anche gli effetti che scattano quando gli alleati usano skill Persona (es. l'attacco aggiuntivo di Mitsuru).
- Da Awareness 6 in su la designazione [Helmsman] non viene rimossa: [Ram: Miracle Ichi-Boat], prima usabile una volta ogni 2 turni, si attiva ogni turno.

**Pro**
- Fornisce cura AoE versatile, rimozione debuff e buff.
- Esegue un attacco aggiuntivo usando affinità e stat del [Helmsman].
- L'attacco aggiuntivo conta come skill Persona, quindi può sfruttare ulteriori sinergie.

**Contro**
- Richiede alleati Summer o Psy nel party per massimizzare l'efficacia.

## Recommended Setup (lufel)
> Nota lufel: le impostazioni consigliate sono basate su contenuti futuri; alcune funzioni potrebbero non essere ancora disponibili (Revelation, Mindscape, ecc.).

- **Revelation** — Space: Perseverance (tooltip "Perseverance - Happiness": quando gli HP di tutti gli alleati sono sotto il 10%, aumenta il Critical Effect del 20%, non cumulabile) · Sun/Moon/Star/Sky: Happiness ×4 (2-Set: Healing Effect +9% · 4-Set: dopo aver prodotto una cura con una skill Persona, aumenta il DMG inflitto di tutti gli alleati del 10% per 2 turni) — set non ancora uscito su Global
- **Main Options** — Sun: HP · Moon: HP · Star: HP · Sky: HP
- **Sub Options** — 1ª priorità: HP · 2ª: Crit Rate / Crit Mult · 3ª: Damage Mult / Pierce Rate
- **Recommended Stats** — LV10: HP 17080 · LV10+Minds 5: HP 18830 · LV13: HP 18130 · LV13+Minds 5: HP 19880
- **Battle Entry +** — Eludi. Stat Buff · Labor 8% · Thieves Den LV50 +260 · Thieves Den LV70 +560 (o più) · Thieves Den Rating
- **Priorità skill** — 1º Skill 3 · 2º Skill 1 · 3º Skill 2 (MAX) · 4º Highlight (livello 8)
- **Mindscape (LV 5)** — Rank Strengthening 1: HP 20% · Rank Strengthening 2: Healing Effect 14.4% · Skill Enforce 1: Skill1 / HIGHLIGHT · Skill Enforce 2: Skill2 / Skill3
- **Skill Rotation** — A0 (Psy): 1 › 3 › 1 › 3 › 1 › 3 · A0 (Summer): 2 › 3 › 2 › 3 › 2 › 3
- **Ichigo Summer Max HP Calculator (lufel)** — la pagina include un calcolatore interattivo degli HP massimi: obiettivo (LV10 / LV10+Mind5 / LV13 / LV13+Mind5), stat base per Awareness (A0 = 4320.0), arma 4★/5★ (5★ = 2283.6 HP), Revelation Sun (1080.0 HP) e Moon/Star/Sky (31.5% ciascuna), sub stat HP% e HP flat, Hidden Ability LV7 HP 29.0%, Rank Strengthening 1 HP (LV0-5), Attribute Mindscape HP (LV1-2, 10.0%), Battle Entry + (Elucidator HP, Labor 8.0%, Thieves Den, Thieves Den Rating). Esempio predefinito: target 17080.0 → totale 16367.3 (−712.7).

## Skills (LV10 / LV10+Minds 5 / LV13 / LV13+Minds 5)
**Skill 1 — Romantic Pearl** (Psy · SP 22)
Infligge danno Psy a nemici casuali pari al 46.2%/50.9%/49.0%/53.7% degli HP massimi di Ichigo (5 colpi). Dal secondo colpo dà priorità a nuovi bersagli e i colpi sullo stesso bersaglio hanno danno ridotto al 25%. Aumenta il danno di tutti gli alleati del 13.7%/15.1%/14.5%/15.9% (in base agli HP massimi di Ichigo, fino a un bonus del 54.7%/60.3%/58.0%/63.6% a 17080/18830/18130/19880 HP massimi) per 2 turni. Se è presente un altro personaggio Psy, concede a Ichigo [Illusion Seal].

**Skill 2 — Astral Anchor** (Psy · SP 22)
Infligge danno Psy a tutti i nemici pari al 46.2%/50.9%/49.0%/53.7% degli HP massimi di Ichigo. Aumenta il danno di tutti gli alleati del 13.7%/15.1%/14.5%/15.9% (in base agli HP massimi di Ichigo, fino a un bonus del 54.7%/60.3%/58.0%/63.6% a 17080/18830/18130/19880 HP massimi) per 2 turni. Se è presente un altro personaggio [Summer], concede a Ichigo [Ocean's Seal].

**Skill 3 — Heart's Desire** (SP 25 · cooldown 1 turno)
Ripristina HP a tutti gli alleati pari al 19.5%/21.5%/20.7%/22.7% degli HP massimi di Ichigo + 1250/1648/1537/1955. Aumenta il Crit Rate di tutti gli alleati del 14.6%/16.1%/15.5%/17.0% per 2 turni. Se Ichigo ha [Illusion Seal]/[Ocean's Seal], spende il Seal corrispondente per aumentare il danno critico di tutti i personaggi Psy/[Summer] del 19.5%/21.5%/20.7%/22.7% (in base agli HP massimi di Ichigo, fino a un bonus del 78.1%/86.1%/82.9%/90.9% a 17080/18830/18130/19880 HP massimi). Poi designa il bersaglio principale della skill come [Helmsman]. Alla fine del turno del [Helmsman], questi usa [Ram: Miracle Ichi-Boat] e poi lascia il ruolo.
[Ram: Miracle Ichi-Boat]: infligge a tutti i nemici danno pari al 48.3%/53.3%/51.3%/56.2% degli HP massimi della [Miracle Ichi-Boat] + 173.7%/191.5%/184.4%/202.2% dell'Attack del [Helmsman]. L'attributo è identico alla Persona del [Helmsman]. Se Ichigo spende un [Seal] usando [Heart's Desire], il moltiplicatore sull'Attack del [Helmsman] per questo danno sale al 347.4%/382.9%/368.7%/404.3%. Questo danno conta come skill Persona ed è calcolato con danno, Damage Amplification, Crit Rate e danno critico del [Helmsman]. Aumenta il danno del 25% per ogni nemico in meno rispetto a 5.

**HIGHLIGHT** (cooldown 4 turni)
Ripristina HP a tutti gli alleati pari al 20.3%/22.4%/21.5%/23.6% degli HP massimi di Ichigo + 1300/1703/1598/2022. Aumenta il loro danno e danno critico del 19.5%/21.5%/20.7%/22.7% per 3 turni.

**Passiva — Words of Love**: quando cura un alleato, gli rimuove 1 debuff e poi aumenta il suo Attack del 30.0% per 1 turno.

**Passiva — Loving Heart**: in battaglia aumenta l'Healing Effect di Ichigo dell'1% ogni 300 punti di HP massimi oltre 8500, fino al 30.0%.

## Awareness
- **A0 — Magical Ichigo Sets Sail** (talento base): prima dell'azione del primo personaggio in battaglia, Ichigo invita tutti gli alleati a salire sulla [Miracle Ichi-Boat]. Gli HP attuali e massimi della [Miracle Ichi-Boat] sono registrati come somma di HP attuali e massimi di tutti gli alleati. Poi riduce gli HP di tutti gli alleati a 1 e concede loro Null Insta-Kill. Quando gli alleati dovrebbero subire danno o ricevere cure, è la [Miracle Ichi-Boat] a subirli. Ichigo sviene quando la [Miracle Ichi-Boat] arriva a 0 HP. Mentre la [Miracle Ichi-Boat] naviga, all'inizio del turno di qualsiasi alleato Ichigo ripristina i suoi HP di un valore pari al 5% degli HP massimi della [Miracle Ichi-Boat].
- **A1 — Ocean's First Glimmer**: aumenta del 20% gli HP massimi della [Miracle Ichi-Boat]. Quando i suoi HP arrivano a 0 per la prima volta, ripristina il 10% dei suoi HP massimi. [Ram: Miracle Ichi-Boat] aumenta inoltre del 50% il danno critico subito dai bersagli per 3 turni.
- **A2 — Tide's Call from Afar**: aumenta del 60% gli effetti buff di [Romantic Pearl] e [Astral Anchor] per il [Helmsman]. All'inizio del turno del [Helmsman], aumenta il suo Attack del 60% per 2 turni.
- **A3 — Two Hearts Meet Here**: aumenta di 3 i livelli di skill di [Astral Anchor] e [Heart's Desire].
- **A4 — The Course Guides the Way**: HIGHLIGHT Enhanced: aumenta il danno del bersaglio principale del 20% e le cure ricevute del 10% per 3 turni.
- **A5 — Destiny Sails Past the Bay**: aumenta di 3 i livelli di skill di [Romantic Pearl] e [Thief Tactics].
- **A6 — Where Miracle Arrives**: [Heart's Desire] aumenta inoltre del 20% la Total Damage Amplification del [Helmsman]. Il [Helmsman] non lascia più il ruolo. Solo 1 alleato può essere [Helmsman] alla volta. Alla fine di ogni turno del [Helmsman] si attiva [Ram: Miracle Ichi-Boat]. Aumenta del 30% lo Skill Damage di [Ram: Miracle Ichi-Boat].

## Stats
- Base (LV1): HP 385 · ATK 81 · DEF 49 · Speed 100
- Hidden Ability LV7: HP % 29%
- LV80 (HP / ATK / DEF): A0 4320 / 920 / 553 · A1 4398 / 937 / 563 · A2 4475 / 953 / 573 · A3 4554 / 970 / 583 · A4 4631 / 986 / 593 · A5 4709 / 1003 / 603 · A6 4786 / 1019 / 613

## Armi esclusive (valori R0/R1/R2/R3/R4/R5/R6)
**5★ Lovey-Dovey Voyager** — HP 2854 · ATK 608 · DEF 366 — passiva *Aqua Vow*
- Aumenta gli HP massimi del 30.0%/30.0%/39.0%/39.0%/48.0%/48.0%/57.0%.
- Quando ottiene un [Seal], aumenta il danno critico (Crit Mult) di tutti gli alleati del 18.1%/23.5%/23.5%/28.9%/28.9%/34.3%/34.3% per 2 turni.
- Aumenta l'Attack del [Helmsman] del 22.6%/29.4%/29.4%/36.2%/36.2%/43.0%/43.0%.

**4★ Chain of Calling** — HP 2284 · ATK 487 · DEF 293 — passiva *Soul Drain*
- Aumenta l'Healing Effect dell'8.7%/8.7%/11.3%/11.3%/13.9%/13.9%/16.5%.
- Quando riceve cure, aumenta il danno del 17.6%/23.2%/23.2%/28.8%/28.8%/34.4%/34.4% per 1 turno.

## Attribute Mindscape (lufel: introdotto in KR V5.2, forse non ancora su Global)
- Mindscape Synergy — **Consciousness Intercept** (consigliata): dopo aver usato una Persona su un nemico, applica al bersaglio 1 stack di "Thought Theft" per 2 turni, cumulabile fino a 3 volte. "Thought Theft": danno subito +1.5%/3.0%.
- Mindscape Combat Skill — **Mental Hunter** (consigliata): quando un nemico ha "Thought Theft", il danno su debolezza Psychokinesis subito da quel nemico aumenta del 2.0%/4.0% (non cumulabile).

## Recommended Combination (lufel)
- Sezione non presente nella pagina lufel di questo personaggio.

## Recommended Parties (lufel)
> Nota lufel: la maggior parte degli esempi di party è stata scritta attorno all'uscita KR/CN del personaggio; Thieves o Mindscape Core successivi potrebbero non essere considerati. Solo riferimento.
- **Lineup** — PINKY: come alleata Psy attiva [Illusion Seal] e può essere designata [Helmsman] per sfruttare l'attacco aggiuntivo. · NOIR: come alleata Psy attiva [Illusion Seal] e può essere designata [Helmsman]. · CHORD·Summer: come alleata [Summer] attiva [Ocean's Seal] e può essere designata [Helmsman]. · KIRIJO: [Ram: Miracle Ichi-Boat] conta come skill Persona di Ichigo Shikano·Summer e attiva un'altra volta l'attacco aggiuntivo di Mitsuru.
- **Party d'esempio** — BERRY·Summer / CHORD·Summer / MONA·Starlight / MIKU · BERRY·Summer / PINKY / KIRIJO / MIKU

## Nomenclatura
- lufel: "Ichigo Shikano·Summer" (codename BERRY·Summer), slug URL `berry-summer`. Stati/risorse: [Miracle Ichi-Boat], [Helmsman], [Ram: Miracle Ichi-Boat], [Illusion Seal], [Ocean's Seal], Thought Theft. [Summer] = tag dei personaggi in versione estiva.
- Nelle descrizioni lufel "critical rate" = Crit Rate, "critical damage"/"Crit DMG" = Crit Mult.
