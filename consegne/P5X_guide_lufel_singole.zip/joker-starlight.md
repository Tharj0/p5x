# Ren Amamiya·Starlight — JOKER·Starlight (dati lufel.net)
Fonte: https://lufel.net/en/character/joker-starlight/ · letto il 2026-11-14 con il browser integrato (spoiler attivi) · Stato Global: NON RILASCIATO (lufel: "Not Released"; il set Wealth è marcato "#NOT RELEASED IN GLOBAL SERVER#").
Convenzione: nomi di skill, awareness, armi, Persona, set e stat lasciati in inglese come su lufel.net; condizioni ed effetti tradotti in italiano. Valori skill = LV10 / LV10+Minds 5 / LV13 / LV13+Minds 5. Valori armi = refinement R0/R1/R2/R3/R4/R5/R6.

## Scheda
| Campo | Valore |
|---|---|
| Nome | Ren Amamiya·Starlight |
| Codename | JOKER·Starlight |
| Persona | Raoul |
| Rarità / tipo | 5★ · Limited (collaborazione P5D) |
| Elemento | Curse (la Skill 3 infligge danno Almighty) |
| Posizione | Virtuoso (alterna Strategist e Saboteur) |
| Ruolo (lufel) | non indicato |
| Tag (lufel) | All-Out Attack · Crit Mult · Crit Rate · Attack · Defense Reduction · Downed damage |
| Resistenza / Debolezza | Res: Curse · Wk: Bless |

## Character Review (lufel)
- Personaggio della collaborazione P5D che può alternare i ruoli Strategist e Saboteur in base al ciclo di skill.
- La Skill 1 è un ottimo buff che aumenta Crit Rate e danno critico di tutti gli alleati, mentre la Skill 2 applica un debuff che riduce la Defense nemica e i Down Point.
- La Skill 3 attiva 『Coordinated Damage』, che prende da ogni alleato la stat di danno più alta, e lancia anche 『Coordinated Strike』 basato sulle stat di Ren.
- Poiché il moltiplicatore di 『Coordinated Damage』 della Skill 3 è già molto alto da Awareness 0, è di fatto completo come sub-DPS.
- Inoltre 『Coordinated Strike』 è un attacco Almighty non influenzato dalla Defense nemica, che tiene comunque conto di Crit Rate e danno critico e beneficia dell'amplificazione All-Out Attack: una skill di danno quasi perfetta, abbastanza forte da farlo funzionare anche come DPS principale autonomo.
- Anche se gli attacchi multi-bersaglio hanno di solito moltiplicatori più bassi, questo guadagna danno al diminuire dei nemici, fino al doppio, quindi è subito utilizzabile anche contro bersaglio singolo.
- Inoltre il solo possederlo aumenta permanentemente di un valore fisso il danno All-Out Attack anche quando non è schierato: migliora le run di Velvet Trial che si basano sugli All-Out Attack e alza il danno dei personaggi influenzati dal danno All-Out Attack.
- I guadagni di Awareness 1 e 2 sono molto superiori a quelli dei Phantom Thieves usciti in precedenza: caso insolito in cui scegliere le Awareness invece dell'arma esclusiva è fortemente consigliato.
- 『Coordinated Strike』: trattato come danno All-Out Attack e beneficia del bonus di danno All-Out Attack dell'utente. Non può andare a critico, ma converte Crit Rate e danno critico in bonus al danno finale. Se i nemici sono meno di 5, il danno aumenta del 25% per ogni nemico mancante.
- 『Coordinated Damage』: calcolato usando Attack più alto, bonus di danno più alto, Crit Rate più alto e danno critico più alto tra gli alleati del team diversi dall'utente.
- 『Phantom Form』: concede immunità ad alterazioni mentali, effetti di controllo e danno ai Down Point. Tuttavia, se Ren Amamiya·Starlight è l'unico alleato in grado di agire, 『Phantom Form』 viene rimosso.

**Pro**
- Aumenta Crit Rate e danno critico di tutti gli alleati.
- Eccellente sub-DPS che infligge danno usando le stat più alte degli alleati.
- Può scegliere in modo flessibile tra modalità Strategist e Saboteur in base alla situazione.
- Ha scaling in base al numero di nemici e attacca con attributo Almighty, quindi non è limitato dal tipo di nemico.

**Contro**
- lufel non ne indica ("-").

## Recommended Setup (lufel)
> Nota lufel: le impostazioni consigliate sono basate su contenuti futuri; alcune funzioni potrebbero non essere ancora disponibili (Revelation, Mindscape, ecc.).

- **Revelation** — Space: Acuity (tooltip "Acuity - Wealth": aumenta il danno All-Out Attack del 10%; dopo aver inflitto danno All-Out Attack, aumenta l'ATK di tutto il party del 15%) · oppure Freedom (tooltip "Freedom - Disappointment": quando infligge danno Almighty, Attack +35% e Crit Rate +12%) · Sun/Moon/Star/Sky: Wealth (2-Set: Attack +12% · 4-Set: DMG inflitto +16%; dopo che l'utente ottiene 2 [Rhapsody Beat], concede il 50% di questo buff parziale agli altri alleati, una volta per battaglia, cumulabile fino a 2 volte — set non ancora uscito su Global) · oppure Disappointment (2-Set: Attack +12% · 4-Set: quando infliggi danno con una skill, se l'attributo è diverso dal danno dell'ultima skill usata, il danno della skill aumenta del 25%)
- **Main Options** — Sun: HP · Moon: Damage Mult / Attack · Star: Crit Mult / Crit Rate · Sky: Attack
- **Sub Options** — 1ª priorità: Crit Mult / Crit Rate · 2ª: Damage Mult / Attack · 3ª: "-"
- **Recommended Stats** — LV10: Crit Mult 197.6% · Attack 3904 | LV10+Minds 5: Crit Mult 207.6% · Attack 4304 | LV13: Crit Mult 203.6% · Attack 4144 | LV13+Minds 5: Crit Mult 213.6% · Attack 4544
- **Battle Entry +** — Attack: Eludi. Stat Buff · Labor 8% · Thieves Den 50LV +65 · Thieves Den 70LV +110 (o più) · Thieves Den Rating · Crit Mult: Eludi. Stat Buff · Thieves Den +2%
- **Priorità skill** — 1º Skill 3 · 2º Skill 1 · 3º Highlight · 4º Skill 2 (tutte MAX)
- **Mindscape (LV 5)** — Rank Strengthening 1: Damage Mult 16% · Rank Strengthening 2: Crit Mult 24% · Skill Enforce 1: Skill1 / Skill2 · Skill Enforce 2: Skill3 / HIGHLIGHT
- **Skill Rotation** — A0 (Strategist): F+1 › 3 › F+1 › 3 › F+1 › 3 · A0 (Saboteur): F+2 › 3 › F+2 › 3 › F+2 › 3
- **Notes (lufel)** — F = FEVER TIME

## Skills (LV10 / LV10+Minds 5 / LV13 / LV13+Minds 5)
**Skill 1 — First Movement** (SP 20)
Aumenta il danno critico (Crit Mult) di tutti gli alleati del 7.8%/8.6%/8.3%/9.1% (in base al danno critico di Ren, fino al 31.2%/34.4%/33.2%/36.4% di danno critico bonus a 197.6%/207.6%/203.6%/213.6% di danno critico) per 2 turni. Ren entra in [Phantom Form]. Se potenziata (boost): aumenta inoltre il Crit Rate di tutti gli alleati del 15.6%/17.2%/16.6%/18.2% e il buff al danno critico sale al 19.5%/21.5%/20.7%/22.7% (in base al danno critico di Ren, fino al 78.1%/86.1%/82.9%/90.9% a 197.6%/207.6%/203.6%/213.6%); concede [Phantom Form] all'alleato con l'Attack più alto (escluso Ren).

**Skill 2 — Syncopated Notes** (Curse · SP 20)
Infligge danno Curse a tutti i nemici pari al 124.6%/137.4%/132.3%/145.1% dell'Attack. Riduce la Defense di tutti i nemici del 9.8%/10.8%/10.4%/11.4% (in base all'Attack di Ren, fino al 39.0%/43.0%/41.4%/45.4% di Defense Down bonus a 3904/4304/4144/4544 di Attack) per 2 turni. Ren entra in [Phantom Form]. Se potenziata: aumenta inoltre il danno subito dai nemici del 48.8%/53.8%/51.8%/56.8% per 2 turni; il debuff Defense Down sale al 19.5%/21.5%/20.7%/22.7% (in base all'Attack di Ren, fino al 78.1%/86.1%/82.9%/90.9% a 3904/4304/4144/4544); il prossimo [Phantom Gala] ignora tutte le affinità e riduce i Down Point del bersaglio di 4; concede [Phantom Form] all'alleato con l'Attack più alto (escluso Ren).

**Skill 3 — Phantom Gala** (Almighty · SP 24)
Condizione d'uso: Ren è in [Phantom Form]. Invita tutti gli alleati a un [Coordinated Strike], infliggendo a tutti i nemici danno Almighty pari al 162.7%/179.4%/172.7%/189.4% dell'Attack e [Coordinated Damage] Almighty pari al 180.8%/199.3%/191.9%/210.4% dell'Attack. Tutti gli alleati escono da [Phantom Form]. Potenziabile spendendo 2 [Rhapsodic Beat], fino a 2 volte: il primo potenziamento porta il moltiplicatore base al 271.1%/298.9%/287.8%/315.6% e quello di [Coordinated Damage] al 301.3%/332.2%/319.8%/350.7%; il secondo porta il moltiplicatore base al 298.2%/328.7%/316.5%/347.0% e quello di [Coordinated Damage] al 331.4%/365.4%/351.8%/385.8%.
[Coordinated Strike]: conta come All-Out Attack e considera le stat di aumento del danno All-Out Attack di chi lo attiva. Non può andare a critico, ma converte Crit Rate e danno critico in Final Damage Bonus. Danno +25% per ogni nemico in meno rispetto a 5.
[Coordinated Damage]: calcolato con Attack, danno, Crit Rate e danno critico più alti tra gli altri alleati (escluso chi lo attiva).
[Phantom Form]: Null Mental/Control Ailment e Null Down per 2 turni. Quando Ren è presente, esce da [Phantom Form] se è l'unico in grado di agire.

**HIGHLIGHT** (cooldown 4 turni)
Aumenta l'Attack di tutti gli alleati del 24.4%/26.9%/25.9%/28.4% e il danno critico (Crit Mult) del 19.5%/21.5%/20.7%/22.7% per 3 turni. Ripristina 1 [Rhapsodic Beat].

**Passiva — Upbeat**: quando Ren entra in [Phantom Form], aumenta l'Attack di Ren del 42.0% e quello degli altri alleati del 30.0% per 2 turni.

**Passiva — Rhythm**: dopo che Ren usa [Fever Time], aumenta il danno di tutti gli alleati del 24.0% (per i personaggi [Starlight] del 36.0% invece) per 2 turni.

## Awareness
- **A0 — Dance Fever Gala** (talento base): dopo aver ottenuto Starlight Ren, gli All-Out Attack degli alleati infliggono 10000/20000/40000 di danno fisso aggiuntivo; per ogni livello di Awareness di Ren questo danno aumenta di 15000/30000/60000 (l'effetto cambia rispettivamente ai livelli 1/50/70). Questo danno fisso aumenta del 30% per ogni nemico in meno rispetto a 3 (vale anche se Ren non è in battaglia). Ren può spendere [Rhapsodic Beat] per potenziare la skill [Phantom Gala]. Ren ha la skill speciale [Fever Time]: ripristina immediatamente 1 [Rhapsodic Beat] e potenzia il prossimo [First Movement] o [Syncopated Notes] (cooldown 1 turno); dopo [Fever Time] Ren può usare altre skill. [Rhapsodic Beat]: risorsa di combattimento condivisa da tutti i personaggi [Starlight], spendibile per potenziare le loro skill; all'inizio del turno dei personaggi [Starlight] ne ripristina 1; si accumula fino a 8.
- **A1 — Picaro**: [Fever Time] ripristina 1 [Rhapsodic Beat] aggiuntivo. Dopo [Fever Time], aumenta il Crit Rate di Ren del 20% e il danno critico (Crit Mult) di tutti gli alleati del 50% per 2 turni.
- **A2 — Restless Starry Night**: quando il party ottiene 1 [Rhapsodic Beat], Ren aumenta l'Attack di tutti gli alleati del 20%; cumulabile fino a 4 volte. Al massimo degli stack, aumenta l'[All-Out Attack Damage] di Ren del 30%.
- **A3 — Starlight Park**: aumenta di 3 i livelli di skill di [Phantom Gala] e [Thief Tactics].
- **A4 — Phantom Dance**: dopo aver usato l'HIGHLIGHT, aumenta inoltre il danno di tutti gli alleati del 25% per 3 turni.
- **A5 — Free Will in Rhythm**: aumenta di 3 i livelli di skill di [First Movement] e [Syncopated Notes].
- **A6 — Dance of Heart's Desire**: [First Movement] potenziato aumenta inoltre del 20% la Total Damage Amplification di tutti gli alleati per 2 turni. [Syncopated Notes] potenziato aumenta inoltre del 20% il Downed Damage Taken di tutti i nemici per 2 turni. Usando [Phantom Gala], attiva un [Coordinated Strike] bonus con lo stato di potenziamento massimo; questo [Coordinated Strike] non spende [Rhapsodic Beat] e aumenta lo Skill Damage del 50%.

## Stats
- Base (LV1): HP 302 · ATK 100 · DEF 53 · Speed 100
- Hidden Ability LV7: ATK % 29%
- LV80 (HP / ATK / DEF): A0 3420 / 1120 / 600 · A1 3482 / 1140 / 611 · A2 3543 / 1160 / 622 · A3 3605 / 1181 / 633 · A4 3666 / 1201 / 643 · A5 3728 / 1221 / 654 · A6 3790 / 1241 / 665

## Armi esclusive (valori R0/R1/R2/R3/R4/R5/R6)
**5★ Jazz Blade** — HP 2259 · ATK 740 · DEF 396
- Aumenta il Crit Rate del 18.1%/18.1%/23.5%/23.5%/28.9%/28.9%/34.3%.
- Mentre [Phantom Form] è attivo, aumenta l'[All-Out Attack Damage] del 12.0%/15.6%/15.6%/19.2%/19.2%/22.8%/22.8%.
- Uscendo da [Phantom Form], aumenta il danno critico (Crit Mult) di tutti gli alleati del 18.1%/23.5%/23.5%/28.9%/28.9%/34.3%/34.3% per 2 turni.

**4★ Baselard** — HP 1808 · ATK 592 · DEF 317
- Aumenta l'Attack del 12.0%/12.0%/16.0%/16.0%/20.0%/20.0%/24.0%.
- Quando spende [Rhapsodic Beat], aumenta il danno dell'utente del 17.6%/23.2%/23.2%/28.8%/28.8%/34.4%/34.4% per 2 turni.

## Attribute Mindscape (lufel: introdotto in KR V5.2, forse non ancora su Global)
- Mindscape Synergy — **Damage Increase** (consigliata): aumenta il danno dell'8.0%/16.0%.
- Mindscape Combat Skill — nessuna consigliata da lufel (slot vuoto, "Click to select").

## Recommended Combination (lufel)
- Sezione non presente nella pagina lufel di questo personaggio.

## Recommended Parties (lufel)
> Nota lufel: la maggior parte degli esempi di party è stata scritta attorno all'uscita KR/CN del personaggio; Thieves o Mindscape Core successivi potrebbero non essere considerati. Solo riferimento.
- **Lineup** — J&C: migliorano molto l'efficienza della Skill 3 di Starlight Ren tramite Skill Amplification. · CROW: Starlight Ren applica danno che scala con le stat di Akechi, mentre Akechi si rafforza sfruttando il danno applicato da Ren.
- **Party d'esempio** — JOKER·Starlight / J&C / CLOSER·Radiance / FUUKA · JOKER·Starlight / J&C / CROW / FUUKA · J&C / MONA·Starlight / MONT·Frostgale / FUUKA · JOKER·Starlight / MONA·Starlight / MONT·Frostgale / MIKU

## Nomenclatura
- lufel: "Ren Amamiya·Starlight" (codename JOKER·Starlight), slug URL `joker-starlight`. Stati/risorse: [Phantom Form], [Coordinated Strike], [Coordinated Damage], [Fever Time], [Rhapsodic Beat] (nei tooltip dei set "Rhapsody Beat"), [Starlight] = tag dei personaggi della collaborazione P5D.
- Nelle descrizioni lufel "critical rate" = Crit Rate, "critical damage" = Crit Mult.
