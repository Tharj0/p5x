# Kira Kitazato — MESSA (dati lufel.net)
Fonte: https://lufel.net/en/character/messa/ · letto il 2026-11-14 con il browser integrato (spoiler attivi) · Stato Global: rilasciato.
Convenzione: nomi di skill, awareness, armi, Persona, set e stat lasciati in inglese come su lufel.net; condizioni ed effetti tradotti in italiano. Valori skill = LV10 / LV10+Minds 5 / LV13 / LV13+Minds 5. Valori armi = refinement R0/R1/R2/R3/R4/R5/R6.

## Scheda
| Campo | Valore |
|---|---|
| Nome | Kira Kitazato |
| Codename | MESSA |
| Persona | Harpyia |
| Rarità / tipo | 5★ · Limited |
| Elemento | Physical |
| Posizione | Assassin |
| Ruolo (lufel) | non indicato |
| Tag (lufel) | Transform · DOT · Pierce Rate · HP Cost |
| Resistenza / Debolezza | Res: Physical · Wk: Gun |
| Mindscape Core | sì (KR V4.7) |

## Character Review (lufel)
- Attaccante Physical single-target che alterna le modalità Doctor e Ripper, accumulando Bleed e detonandolo tramite il danno Rending.
- Da Awareness 0-1 Kira si concentra su accumulare e mantenere gli stack di Bleed come "tipo Bleed"; da Awareness 6 passa a un "tipo Burst" che attiva ripetutamente Rending. Il gioco orientato al burst diventa praticabile da Awareness 1.
- A0-A1 (tipo Bleed): concentrarsi su accumulare e rinnovare Bleed in modalità Doctor. Usa S1 → HL per applicare 5 stack → mantieni con S2 → entra brevemente in modalità Ripper a fine turno.
- A6 (tipo Burst): concentrarsi su attivare ripetutamente Rending in modalità Ripper. Raggiunti 13 stack di Bleed, attiva Nightfall → concatena S1/S2 per i burst di Rending.
- **Attivazione del Mindscape Core**: Kira ha ottenuto una skill che, alla fine del turno di ogni nemico, riduce permanentemente gli HP massimi di quel nemico dell'1.25% per ogni stack di Bleed, fino al 50%. A 10 stack può ridurre gli HP di qualsiasi boss del 50% in 5 turni, migliorando molto l'utilità generale. Ha anche ottenuto una passiva che gli permette di fungere da sub-DPS a danno continuo o da sub-DPS in coppia con DPS Physical. Con il Mindscape Core ha ricevuto più buff e rework di sistema: tutto il danno di skill Persona e HIGHLIGHT è ora trattato come danno continuo, beneficiando di ogni buff legato al "damage over time amp"; inoltre il danno Rending della S2 può ora andare a critico, migliorando il valore dei buff di Crit Rate e danno critico, prima una delle sue limitazioni. ※ Dopo questa patch, danno critico e Crit Rate sono diventati molto più preziosi nelle build di Kira. Gli effetti di riduzione del danno in scala con gli HP posseduti dai boss sono stati rimossi; il limite è diventato un tetto in scala con l'Attack, dando valore reale al danno Bleed nei contenuti competitivi.

**Pro**
- Può ripulire efficientemente la modalità storia grazie al danno in scala con gli HP.

**Contro**
- La maggior parte dei boss ha effetti di riduzione del danno in scala con gli HP, che riducono drasticamente l'efficacia del danno Bleed di Kira (nota: vedi la sezione Mindscape Core per il cambiamento).

## Recommended Setup (lufel)
> Nota lufel: le impostazioni consigliate sono basate su contenuti futuri; alcune funzioni potrebbero non essere ancora disponibili (Revelation, Mindscape, ecc.).

- **Revelation** — Space: Wisdom (tooltip "Wisdom - Oppression": Physical DMG e Ailment Accuracy Rate +20% con [Resentment] ad almeno 5 stack · "Wisdom - Pleasure": aumenta il DMG Bonus fino al 30% in base al 50% del proprio Ailment Accuracy Rate) · oppure Perseverance (tooltip "Perseverance - Sorrow": aumenta il danno continuo del 16%) · Sun/Moon/Star/Sky: Oppression (2-Set: Physical DMG +10% · 4-Set: ottiene [Resentment] dopo ogni colpo di danno da skill: ATK +5% per 2 turni, fino a 6 stack) · oppure Pleasure (2-Set: Psy DMG +10% · 4-Set: ATK +15% quando infligge danno Psy; con più di 3 nemici in campo, ATK +15% in più) · oppure Sorrow (2-Set: ATK +12% · 4-Set: DMG +20% per 3 turni; si riottiene usando HIGHLIGHT)
- **Main Options** — Sun: HP · Moon: Attack / Damage Mult · Star: Attack · Sky: Attack
- **Sub Options** — 1ª priorità: Pierce Rate · 2ª: Attack / Damage Mult / Ailment Accuracy · 3ª: Crit Mult / Crit Rate
- **Recommended Stats** — LV10: "-" · LV10+Minds 5: "-" · LV13: Pierce Rate 31.5% (A6) · LV13+Minds 5: Pierce Rate 31.5% (A6); Battle Entry +: "-"
- **Priorità skill** — 1º Skill 2 · 2º Skill 1 · 3º Skill 3 · 4º Highlight (tutte MAX)
- **Mindscape (LV 5)** — Rank Strengthening 1: Attack 20% · Rank Strengthening 2: Pierce Rate 7.5% · Skill Enforce 1: Skill1 / HIGHLIGHT · Skill Enforce 2: Skill2 / Skill3
- **Skill Rotation** — A0: 1 › 1 › 2 › 2 › 2 › 3+2 · A1: 1 › 3+1 › 1 › 2 › 3+1 › 3+2 · A6: 1 › 3+1 › 3+1 › 2 › 3+1 › 3+2
- **Notes (lufel)** — Regola il rapporto tra "hunter/executioner" (Doctor/Ripper) in base alla durata del danno · La tattica cambia molto a seconda che si usi o meno l'HL

## Skills (LV10 / LV10+Minds 5 / LV13 / LV13+Minds 5)
**Skill 1 — Moonlit Scalpel / Midnight Surgery** (Physical · SP 21)
Modalità Doctor (Moonlit Scalpel): infligge danno Physical a 1 nemico pari al 47.3%/52.2%/50.2%/55.1% dell'Attack (4 colpi) e applica 1 stack di Bleed. Modalità Ripper (Midnight Surgery): infligge danno Physical a 1 nemico pari al 251.7%/277.5%/267.2%/292.9% dell'Attack, poi rimuove 2 stack di Bleed dal bersaglio (può attivare gli effetti Rending).

**Skill 2 — Crimson Operation / Pathology** (Physical · SP 21)
Modalità Doctor (Crimson Operation): infligge danno Physical a 1 nemico pari all'84.2%/92.9%/89.4%/98.0% dell'Attack (2 colpi). Contemporaneamente attiva 1 volta il danno Bleed e azzera (rinnova) la durata in turni degli stack di Bleed del bersaglio. Modalità Ripper (Pathology): infligge danno Physical a 1 nemico pari al 251.7%/277.5%/267.2%/292.9% dell'Attack. Per ogni stack di Bleed sul bersaglio, aumenta del 2% il danno dei Rending attivati e di questa skill, poi rimuove tutti gli stack di Bleed dal bersaglio (può attivare gli effetti Rending).

**Skill 3 — Nightfall** (SP 15)
Passa in modalità Ripper e cambia le skill di Kitazato (attivabile quando un nemico ha 7 o più stack di Bleed). Usando skill in questa modalità, ogni 3 stack di Bleed sul bersaglio applica 1 stack di Rending (danno Physical pari al 66.7%/73.5%/70.8%/77.6% dell'Attack). Dopo questa skill Kitazato può usare altre skill e torna in modalità Doctor alla fine del turno.

**HIGHLIGHT** (cooldown 4 turni)
Passa in modalità Doctor e applica subito 5 stack di Bleed a 1 nemico. Poi passa subito in modalità Ripper e infligge al bersaglio danno Physical pari al 492.8%/543.3%/523.1%/573.6% dell'Attack (può attivare gli effetti Rending).

**Passiva — Hideous Mask**: ogni 30% di Ailment Accuracy di Kitazato, aumenta il danno Physical di Bleed del 4% dell'Attack (fino al 90% di Ailment Accuracy).

**Passiva — Drawn Blade**: in modalità Doctor, Ailment Accuracy +36%. In modalità Ripper, Pierce Rate +21%.

## Awareness
- **A0 — Mortal Responsibility** (talento base): Kitazato ha 2 modalità, Doctor e Ripper, e le proprietà delle skill cambiano con la modalità; inizia in Doctor. Doctor: ogni volta che infligge danno con una skill, 70% di probabilità di applicare 1 stack di Bleed al bersaglio; quando un nemico con Bleed viene sconfitto, i suoi stack passano al nemico con più HP; può spendere SP per usare skill Physical. Ripper: usando una skill, applica 1 stack di Rending ogni 3 stack di Bleed sul bersaglio. Bleed: ogni turno infligge danno Almighty pari all'1% degli HP massimi del bersaglio + danno Physical pari al 4% dell'Attack di Kitazato; dura 4 turni; fino a 10 stack. Rending: infligge danno Physical in base all'Attack di Kitazato e al livello di Nightfall (non può andare a critico né infliggere danno ai Down Point).
- **A1 — Abdominal Incisions**: in modalità Doctor, la prima volta che infligge danno da skill a ciascun nemico, applica 5 stack di Bleed in più. In modalità Ripper, usando una skill su un nemico, aumenta il danno di quella skill in base al numero di debuff sul bersaglio; con 10 o più debuff l'effetto è al massimo e il danno della skill sale fino all'80%. Inoltre moltiplica per 1.5 il danno Almighty di Bleed.
- **A2 — Forbidden Transfusion**: aumenta il moltiplicatore di Attack di Rending del 35% dell'Attack di Kitazato. Ripristina HP a Kitazato pari al 2% del danno Rending inflitto (fino a livello di Kitazato × 15 + 300 per turno).
- **A3 — Master of the Scalpel**: aumenta di 3 i livelli di skill di Moonlit Scalpel / Midnight Surgery e Thief Tactics.
- **A4 — Bloody Bacchanal**: Highlight Enhanced: danno dell'Highlight +8% per ogni stack di Bleed sul bersaglio.
- **A5 — Razor-Sharp Focus**: aumenta di 3 i livelli di skill di Crimson Operation / Pathology e Nightfall.
- **A6 — Great Doctor**: aumenta a 13 gli stack massimi di Bleed; inoltre ogni nemico ha sempre almeno 3 stack di Bleed. Usando Midnight Surgery in modalità Ripper, non rimuove gli stack di Bleed del bersaglio. Inoltre evolve gli effetti Rending in Killing Frenzy: danno +100% e infligge il 50% del danno a tutti gli altri nemici; Killing Frenzy può attivare gli effetti di Rending con tutte le skill.

## Stats
- Base (LV1): HP 331 · ATK 100 · DEF 48 · Speed 97
- Hidden Ability LV7: ATK % 29%
- LV80 (HP / ATK / DEF): A0 3720 / 1130 / 547 · A1 3787 / 1150 / 556 · A2 3854 / 1171 / 567 · A3 3921 / 1191 / 576 · A4 3988 / 1212 / 586 · A5 4055 / 1232 / 596 · A6 4122 / 1252 / 606
- LV100 (HP / ATK / DEF): A0 4602 / 1398 / 676 · A1 4686 / 1423 / 688 · A2 4769 / 1449 / 701 · A3 4853 / 1474 / 713 · A4 4937 / 1500 / 725 · A5 5021 / 1525 / 738 · A6 5104 / 1551 / 750

## Armi esclusive (valori R0/R1/R2/R3/R4/R5/R6)
**5★ Bloodletter** — HP 2458 · ATK 747 · DEF 361
- Aumenta l'Attack del 30.0%/30.0%/39.0%/39.0%/48.0%/48.0%/57.0%.
- Aumenta l'Ailment Accuracy del 15%.
- Aumenta il Pierce Rate del danno Rending del 25.0%/32.5%/32.5%/40.0%/40.0%/47.5%/47.5%.
- Aumenta il danno inflitto ai nemici con Bleed del 25.0%/32.5%/32.5%/40.0%/40.0%/47.5%/47.5%.

**4★ Undying Embers** — HP 1966 · ATK 597 · DEF 289
- Aumenta l'Attack del 12.0%/12.0%/16.0%/16.0%/20.0%/20.0%/24.0%.
- Ogni volta che applica Bleed ai nemici, aumenta ulteriormente l'Attack dell'1.8%/2.4%/2.4%/3.0%/3.0%/3.6%/3.6%; permanente, fino a 10 stack.

## Attribute Mindscape (lufel: introdotto in KR V5.2, forse non ancora su Global)
- Mindscape Synergy — **Critical Damage Increase** (consigliata): aumenta il danno critico (Crit Mult) del 12.0%/24.0%.
- Mindscape Combat Skill — **Opening Pursuit** (consigliata): quando un alleato Physical attacca un nemico con "Vulnerability", l'amplificazione totale del danno aumenta del 2.5%/5.0% (non cumulabile).

## Mindscape Core (lufel: introdotto in KR V4.7; sbloccandolo si può raggiungere il LV100)
- Mindscape Amplification (×100): Final Damage +2% a tutti gli alleati di attributo Physical.
- Mindscape Amplification (×100): Physical Attribute Damage Mult +8% e Physical DMG Taken −10% a tutti gli alleati Physical.
- **Frenzy** (×24): alla fine del turno di ogni nemico, riduce permanentemente i suoi HP massimi dell'1.25% per ogni stack di Bleed (fino al 50%). In modalità Doctor, Attack +20.0%/30.0%/40.0%; in modalità Ripper, danno critico +20.0%/30.0%/40.0%.
- **Bloodlust** (×24): aumenta lo skill damage di Rending e Killing Frenzy del 7.5%/11.2%/15.0% + livello di Awareness × 8%. Dopo Nightfall, aumenta gli effetti di danno continuo di tutti gli alleati del 10.0%/15.0%/20.0% + livello di Awareness × 5% per 2 turni. Quando gli alleati Physical infliggono danno, se il nemico ha 7 o più stack di Bleed, total damage amp +10.0%/15.0%/20.0% + livello di Awareness × 5% e danno +20.0%/30.0%/40.0% + livello di Awareness × 10%.

## Recommended Combination (lufel)
> Nota lufel: alcune Persona e armi consigliate potrebbero non essere ancora uscite nella tua regione.
- **Wonder Weapons**: Eye of Obsequies · Ex Machina
- **Persona (ATK)**: Lilith · Koumokuten · Jikokuten · Dominion — nota lufel: aumenta il danno DOT mettendo l'attributo Almighty davanti e potenziando il danno elementale tramite la Wonder weapon.
- **Persona (CRITICAL)**: Dionysus · Yurlungur
- **Persona (REDUCE DEF)**: Janosik · Vishnu · Norn

## Recommended Parties (lufel)
> Nota lufel: la maggior parte degli esempi di party è stata scritta attorno all'uscita KR/CN del personaggio; Thieves o Mindscape Core successivi potrebbero non essere considerati. Solo riferimento.
- **Lineup** — CHORD: può accumulare Bleed usando l'Highlight per attivare 5 stack. · MOKO·Seaside: aumenta Ailment Accuracy e Attack, fornendo anche Healing Effect.
- **Party d'esempio** — MESSA / MARIAN / CHORD / PHOEBE · MESSA / MOKO·Seaside / CHORD / PHOEBE · MESSA / LEON / CHORD / PHOEBE · MESSA / MOKO·Seaside / CHORD / ORACLE

## Nomenclatura
- lufel: "Kira Kitazato" (codename MESSA), slug URL `messa`. Stati/risorse: Bleed, Rending → Killing Frenzy (A6), modalità Doctor / Ripper (nelle note della rotazione "hunter/executioner"), [Resentment] (Revelation Oppression).
- Nelle descrizioni lufel "ailment accuracy" = Ailment Accuracy, "critical rate" = Crit Rate, "critical damage" = Crit Mult.
